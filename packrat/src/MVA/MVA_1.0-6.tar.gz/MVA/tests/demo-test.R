
library("MVA")

sapply(demo(package = "MVA")$results[, "Item"], demo, character.only = TRUE,
       ask = FALSE)

