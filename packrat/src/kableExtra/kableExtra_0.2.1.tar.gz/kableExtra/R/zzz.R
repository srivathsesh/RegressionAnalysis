.onLoad <- function(libname = find.package("kableExtra"), pkgname = "kableExtra") {
  usepackage_latex("booktabs")
  usepackage_latex("longtable")
}
