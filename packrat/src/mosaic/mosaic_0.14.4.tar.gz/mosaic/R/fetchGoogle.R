#' @rdname defunct-fetch
#' @export 
fetchGoogle <- function(...) {
  .Defunct(msg="Use fetchGoogle() from the `fetch' package instead. Or see the `googlesheets' package.")
}
